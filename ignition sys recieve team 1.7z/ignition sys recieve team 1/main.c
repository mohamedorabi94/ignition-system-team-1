

/**
 * main.c
 */

#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"

#include "include/FreeRTOS.h"
#include "include/task.h"
#include "include/queue.h"
#include "include/semphr.h"

#include "Types.h"
#include "TASK.h"

//*****************************************************************************
//
// This hook is called by FreeRTOS when an stack overflow error is detected.
//
//*****************************************************************************
void
vApplicationStackOverflowHook(TaskHandle_t *pxTask, char *pcTaskName)
{
    //
    // This function can not return, so loop forever.  Interrupts are disabled
    // on entry to this function, so no processor interrupts will interrupt
    // this loop.
    //
    while(1)
    {
    }
}

int main(void)
{



    /* Create the queue, storing the returned handle in the xQueue variable. */
     xQueue = xQueueCreate( QUEUE_LENGTH, QUEUE_ITEM_SIZE );


    xTaskCreate( Tasks_Init, NULL, configMINIMAL_STACK_SIZE, NULL, NUM_3, NULL);
    xTaskCreate( SPI_R, NULL, configMINIMAL_STACK_SIZE, NULL, NUM_2, NULL);
    xTaskCreate( LCD, NULL, configMINIMAL_STACK_SIZE, NULL, NUM_1, NULL);


    //
    // Start the scheduler.  This should not return.
    //
    vTaskStartScheduler();

    //
    // In case the scheduler returns for some reason, print an error and loop
    // forever.
    //

    while(1)
    {
    }
}
