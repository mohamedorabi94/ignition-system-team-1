/*
 * TASK.h
 *
 *  Created on: Mar 18, 2019
 *      Author: AVE-LABS-50
 */

#ifndef TASK_H_
#define TASK_H_
#include "include/event_groups.h"
#include "include/queue.h"

typedef void * TaskHandl;

QueueHandle_t xQueue;


#define QUEUE_LENGTH 4
#define QUEUE_ITEM_SIZE 1


/*********************************************************************************/
/* FUNCTION NAME: SPI_R                                                          */
/* @Param: *pvParameters                                                         */
/* return: void                                                                  */
/* FUNCTION Description: task receive data from spi                              */
/*********************************************************************************/
 void SPI_R(void *pvParameters);

 /*********************************************************************************/
 /* FUNCTION NAME: LCD                                                            */
 /* @Param: *pvParameters                                                         */
 /* return: void                                                                  */
 /* FUNCTION Description: display lcd                                             */
 /*********************************************************************************/
 void LCD(void *pvParameters);


/*********************************************************************************/
/* FUNCTION NAME: Tasks_Init                                                     */
/* @Param: *pvParameters                                                         */
/* return: void                                                                  */
/* FUNCTION Description: initialization of GPIO for led and pushbutton and lcd   */
/*********************************************************************************/
 void Tasks_Init(void *pvParameters);



#endif /* TASK_H_ */
