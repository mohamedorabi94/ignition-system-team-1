/*
 * TASK.c
 *
 *  Created on: Mar 18, 2019
 *      Author: AVE-LABS-50
 */




#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "inc/hw_memmap.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"

#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"

#include "LCD/LCD.h"
#include "SPI_FILE/SPI.h"
#include "TASK.h"
#include "Types.h"
#include "include/task.h"

#define mask_Dist 0x1f
#define mask_CMD 0xE0

 TaskHandl x ;
 QueueHandle_t SPI_RECIEVE_H;

#if 0
 uint8_t volatile i=NUM_0 ;
 uint8_t volatile j=NUM_0 ;
 uint8_t volatile flag=NUM_0 ;

 uint16_t volatile count1=NUM_0 ;
 uint16_t volatile count2=NUM_0 ;



 void LED1_Blinking(void *pvParameters){

     while(1)
     {

             GPIOPinWrite(GPIO_PORTF_BASE,(GPIO_PIN_1), (GPIO_PIN_1)); /* set high on led */
             vTaskDelay(NUM_100); /* delay 100m sec */

     }
 }
#endif

 /*********************************************************************************/
 /* FUNCTION NAME: Tasks_Init                                                     */
 /* @Param: *pvParameters                                                         */
 /* return: void                                                                  */
 /* FUNCTION Description: initialization of GPIO for led and pushbutton           */
 /*********************************************************************************/
 void Tasks_Init(void *pvParameters)
 {
     while(1)
     {
         SPI_RECIEVE_H  = xQueueCreate( NUM_10 , 4 );
         LCD_INIT(); /* initialization of lcd */
         SPI_RECIEVE_INIT(); /* initialization of spi */
         vTaskSuspend(x); /* suspend the task */
     }
}

 /*********************************************************************************/
 /* FUNCTION NAME: SPI_R                                                          */
 /* @Param: *pvParameters                                                         */
 /* return: void                                                                  */
 /* FUNCTION Description: task receive data from spi                              */
 /*********************************************************************************/
 void SPI_R(void *pvParameters)
 {
     uint32_t X = NUM_0 ;
     while(NUM_1)
     {
         SPI_RECIEVE_INIT(); /* initialization of spi */
         X=SPI_RECIEVE();/* receive data from spi */
         if(X)
         {
             /* put received data in queue */
             xQueueOverwrite(SPI_RECIEVE_H,&X);
             vTaskDelay(500);


             GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_1,0);/*led off*/

         }
         vTaskDelay(NUM_2);

     }
 }




 /*********************************************************************************/
 /* FUNCTION NAME: LCD                                                            */
 /* @Param: *pvParameters                                                         */
 /* return: void                                                                  */
 /* FUNCTION Description: display lcd                                             */
 /*********************************************************************************/
void LCD(void *pvParameters)
{

    /* create strings for displaying it on lcd */
    const uint8_t state0[NUM_7] = "SYS OFF";
   const uint8_t state1[NUM_13] = "MaintainSpeed";
   const uint8_t state2[NUM_10] = "Rise Spead";
   const uint8_t state3[NUM_9] = "Brake Sys";
   const uint8_t state4[NUM_10] = "Lose Speed";
   const uint8_t state5[NUM_7] = "Air Bag";

   uint32_t xMessage ;
   uint8_t LCD_f=NUM_0,State=NUM_0;

    while(1)
    {
        if(LCD_f==NUM_0 )
        {
            LCD_Send_Command (CLEAR_LCD);/*clear lcd*/
            LCD_gotoRowColumn(FirstLine,NUM_4);/*go to the FirstLine in lcd*/
            LCD_displayString(state0,NUM_7);/*Print system off*/
            vTaskDelay(NUM_900);
            //

            LCD_f=NUM_1;

        }
        if( xQueueReceive( SPI_RECIEVE_H, &xMessage, portMAX_DELAY ) == pdPASS )
        {
            State=(uint32_t)((xMessage&mask_CMD)>>NUM_5);
            switch (State)
            {
                case NUM_1:/*MaintainSpeed*/
                    LCD_Send_Command (CLEAR_LCD);/*clear lcd*/
                    LCD_gotoRowColumn(FirstLine,NUM_0);/*go to the FirstLine in lcd*/
                    LCD_displayString(state1,NUM_13); /*Print state1*/
                   break;
                case NUM_2:/*Rise Spead*/
                    LCD_Send_Command (CLEAR_LCD);/*clear lcd*/
                    LCD_gotoRowColumn(FirstLine,NUM_0);/*go to the FirstLine in lcd*/
                    LCD_displayString(state2,NUM_10); /*Print state2*/
                   break;
                case NUM_3:/*Brake Sys*/
                    LCD_Send_Command (CLEAR_LCD);/*clear lcd*/
                    LCD_gotoRowColumn(FirstLine,NUM_0);/*go to the FirstLine in lcd*/
                    LCD_displayString(state3,NUM_9); /*Print state3*/
                   break;
                case NUM_4:/*Lose Speed*/
                    LCD_Send_Command (CLEAR_LCD);/*clear lcd*/
                    LCD_gotoRowColumn(FirstLine,NUM_0);/*go to the FirstLine in lcd*/
                    LCD_displayString(state4,NUM_10);/*Print state4*/
                   break;
                case NUM_5:/*Air Bag*/
                    LCD_Send_Command (CLEAR_LCD);
                    LCD_gotoRowColumn(FirstLine,NUM_0);/*go to the FirstLine in lcd*/
                    LCD_displayString(state5,NUM_7);/*Print state5*/
                   break;
                case NUM_7:/* system off*/
                   LCD_Send_Command (CLEAR_LCD);/*clear lcd*/
                   LCD_gotoRowColumn(FirstLine,NUM_4);/*go to the FirstLine in lcd*/
                   LCD_displayString(state0,NUM_7); /*Print system off*/
                   break;

            }
            if(State!=NUM_5 && State!=NUM_7)
            {

                LCD_gotoRowColumn(SecondLine,NUM_0);          /*go to the Second row in lcd*/
                LCD_displayString("DISTANCE:",NUM_9);         /*Print*/
                LCD_gotoRowColumn(SecondLine,NUM_10);          /*go to the Second row in lcd*/
                PrintDecimalNum((uint32_t)xMessage&mask_Dist); /*Print distance*/
            }


        }
       vTaskDelay(300);

    }


}


